package com.example.a11pr_tsarevnikita_pr_21102;

import static java.lang.Thread.sleep;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    TextView tv_result;
    Button btn_orange, btn_green, btn_start;
    ImageView orange, green;
    Switch bot;

    boolean game_started;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_result = (TextView) findViewById(R.id.text_result);
        btn_start = (Button) findViewById(R.id.btn_start);
        btn_orange = (Button) findViewById(R.id.btn_drive_orange);

        orange = (ImageView) findViewById(R.id.car_orange);
        green = (ImageView) findViewById(R.id.car_green);
        bot = (Switch) findViewById(R.id.switch_bot);

        tv_result.setVisibility(View.INVISIBLE);
    }

    void finish_game() {

        btn_start.setText(R.string.btn_start_game);
        tv_result.setVisibility(View.VISIBLE);
        game_started = false;
    }

    public void onclick_orange(View v) {

        if (game_started) {
            ViewGroup.MarginLayoutParams margin = (ViewGroup.MarginLayoutParams) orange.getLayoutParams();
            margin.leftMargin += Math.random() * 20 + 20;

            orange.requestLayout();

            if (margin.leftMargin > 1600) {

                tv_result.setText(R.string.win_orange);
                tv_result.setTextColor(getResources().getColor(R.color.orange));

                finish_game();
            }
        }

    }

    public void onclick_green(View v) {

        if (game_started) {
            ViewGroup.MarginLayoutParams margin = (ViewGroup.MarginLayoutParams) green.getLayoutParams();
            margin.leftMargin += Math.random() * 20 + 20;
            green.requestLayout();

            if (margin.leftMargin > 1600) {

                tv_result.setText(R.string.win_green);
                tv_result.setTextColor(getResources().getColor(R.color.green));

                finish_game();
            }
        }
    }

    public void onclick_start(View v) {

        game_started = !game_started;

        ViewGroup.MarginLayoutParams margin = (ViewGroup.MarginLayoutParams) orange.getLayoutParams();
        ViewGroup.MarginLayoutParams margin2 = (ViewGroup.MarginLayoutParams) green.getLayoutParams();

        margin.leftMargin = 8;
        margin2.leftMargin = 8;

        if (game_started) {
            btn_start.setText(R.string.btn_stop_game);
            tv_result.setVisibility(View.INVISIBLE);

            orange.requestLayout();
            green.requestLayout();

            if (bot.isChecked()) {

                btn_orange.setVisibility(View.INVISIBLE);

                Thread t = new Thread(new Runnable() {
                    public void run() {

                        while (game_started) {

                            runOnUiThread(runner);

                            try {
                                TimeUnit.MILLISECONDS.sleep(225);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                });
                t.start();
            }
            else {
                btn_orange.setVisibility(View.VISIBLE);
            }

        }
        else {
            btn_start.setText(R.string.btn_start_game);
        }
    }

    Runnable runner = new Runnable() {
        public void run() {
            onclick_orange(null);
        }
    };
}